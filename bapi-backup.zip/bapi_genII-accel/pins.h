/*
 * pins.h
 *
 *  Created on: Jan 13, 2016
 *      Author: Kristian Sims
 */

#ifndef PINS_H_
#define PINS_H_

// Port 1
#define BB_I2C_SCL_PIN			BIT1
#define BB_I2C_SDA_PIN			BIT0


#endif /* PINS_H_ */
